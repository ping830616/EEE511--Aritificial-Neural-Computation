Please run team14_competition.py file in python with the following packages installed
Python Version 3.7.3
Pytorch - Version 1.7.1+cpu
numpy - version 1.19.2

team14_competition.py may be run in an Anaconda Prompt or in Spyder 4.2.3 (Python 3.7)

Here is version information for the anaconda environment:

# Name                    Version                   Build  Channel
_anaconda_depends         2020.07                  py37_0
anaconda                  custom                   py37_1
anaconda-client           1.7.2                    py37_0
anaconda-navigator        1.9.7                    py37_0
anaconda-project          0.9.1              pyhd3eb1b0_1
conda                     4.9.2            py37haa95532_0
conda-build               3.17.8                   py37_0
conda-env                 2.6.0                         1
conda-package-handling    1.7.2            py37h76e460a_0
conda-verify              3.1.1                    py37_0
msys2-conda-epoch         20160418                      1

When run team14_competition.py will ask how you want to test against pre-trained models or if you want to retrain each of the networks.

Ground truth may also be supplied as a list of values from a comma-delimited CSV file. The first column of values will be loaded into the program and everything else ignored.
Please not not include data labels in ground-truth CSV file- only data points in the first column.
Please save a comma delimited file into the same working directory that the python file is run. The program will ask for the name of the file saved in the same directory or hit enter to default search for "ground_truth.csv"

Once ground truth values have been loaded then MSE for each model will be calculated and displayed on the screen.

To calculate by hand, load each network class either by loading from memory or training.
Build a Pytorch tensor from ground truth values using features specific to each network:
Reference below for the order of each feature within the Pytorch tenor

3-Parameter input dimension: samples rows X 2 columns
x(n-1)^2,x(n-1)

15-Parameter input dimension: samples rows X 2 columns
x(n-2),x(n-1)

75-Parameter and 75-Parameter with regularization input dimension: samples rows X 3 columns
x(n-2), x(n-1)^2, x(n-1)

orward propogate through each model by running the "forward()" method, example:

net3.forward(inp)

The output from the above operation is saved in "net3.out" Pytorch tensor

From there you can use Pytorch methods to calculate MSE quickly, example:

MSE = (ground_truth - net3.out).square().sum()/net3.out.shape[0]