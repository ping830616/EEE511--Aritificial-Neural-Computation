# -*- coding: utf-8 -*-
"""
Created on Tue Mar 23 22:29:04 2021

@author: Vince Bevilacqua
"""
# Team 14 Midterm 
#import necessary libraries
import torch
import math
import time
import pickle

#bring data in from csv as a python list of float values
fil = open('IPG2211A2N_1.csv','r')

data = []

x = fil.readline()

while x != '':
    data.append(x)
    x = fil.readline()
fil.close()

fdata = []

for i in data:
    fdata.append(float(i[:-1]))


#convet data in pytorch tensor
data = torch.tensor(fdata)
data.unsqueeze_(-1)

#establish class for creating networks
#having a class with reproducible scheme for building network structure
#will help with optimizing to find the best fit code
class network():#network class
    
    def linear(inpt):#define deault linear function
        return inpt

    def __init__(self,features,structure=[1],bias=True,activation=linear):#initialize network
        self.features = features#number of input features e.g. x(n-1), x(n-1)**2 etc
        self.structure = structure#save network structure for reference while troubleshooting
        self.activation = activation#activation function, default is linear
        self.eta = 0.001#learning rate
        self.lam = 0.001#parameter regularization rate
        self.weights = []#python list containing pytorch tensors comprising weights - these are all of our parameters
        self.layers = []#python list for storing layer activations (list will contain pytorch tensors)
        self.bias = bias#True/False to include bias as part of network structure
        self.rss = 0#root sum square heuristic of parameter gradients for measuring how trained our model is
        self.mse = 0#mean square error of model data to ground truth
        self.scale = torch.diag(torch.ones(features))#pytorch diagonal matrix for normalizing inputs
        self.out_scale = 1#scalar value for rescaling output (useful for sigmoid activations)
        
        inp = features
        for idx in structure:#initialize weight matrices
            if bias:#if bias =True then include an additional column of weights (augment input matrix with 1's)
                self.weights.append(torch.randn(inp+1,idx,requires_grad=True))
            else:
                self.weights.append(torch.randn(inp,idx,requires_grad=True))
            inp = idx
    
    def forward(self,inpt):#inference method
        self.layers = []
        vlayer = inpt@self.scale#condition inputs to avoid extraneous parameter values
        for idx in self.weights:#propogate network activations
            if self.bias:
                templayer = torch.cat((vlayer,torch.ones(vlayer.shape[0]).unsqueeze(-1)),1)#augment input matrix to account for biases
                self.layers.append(self.activation(templayer@idx))
            else:
                self.layers.append(self.activation(vlayer@idx))
            vlayer = self.layers[-1]
        self.out = self.layers[-1]/self.out_scale#output is the last layer scaled by the predetermined output scale
        #scaling the output allows for networks with sigmoid activations to achieve ouput values higher than 1

    def train(self,inpt,truth,param_reg = False):#training method
        self.out_scale = .99/truth.abs().max().item()#determine appropriate scale for output
        self.forward(inpt)#forward propagation
        self.rss = 0#initialize gradient heuristic
        if param_reg:#regularization
            params = 0
            for idx in self.weights:#calculate square sums of parameters
                params += idx.square().sum()
            self.error = (truth-self.out).square().sum()/inpt.shape[0] + self.lam*params#regularization
        else:#otherwise calculate error of all samples at once
            self.error = (truth-self.out).square().sum()/inpt.shape[0]#matrices allow full sweep through all datapoints in one go (benefit of pytorch library)
        self.mse = self.error.item()
        self.error.backward()#pytorch method for backward propogation- this method calculates all gradients
        with torch.no_grad():#need to perform these calculations in a different python "context" to avoid making them part of the gradient at the backward propogation
            for idx in range(len(self.weights)):#cycle through all weight matrices (i.e. each layer)
                self.weights[idx] -= self.eta*self.weights[idx].grad#update parameters (weights) gradient descent and learning rate (eta)
                self.rss += self.weights[idx].grad.square().sum().item()#calculate gradient heuristic (for stopping criteria)
                self.weights[idx].grad.zero_()#pytorch necessity: clean up gradient tensors otherwise results accumulate
                
    def normalize(self,inpt):#calculate scale for normalizing input data- this will be needed for inference later
        for idx in range(inpt.shape[1]):
            self.scale[idx][idx] = inpt.shape[0]/inpt.T[idx][:].sum().item()
                    
    def reset(self):#reset newtork for troubleshooting and retraining (useful when training model become unstable due to bad learning rate)
        for idx in range(len(self.weights)):#re-initialize parameters
            self.weights[idx] = torch.randn(self.weights[idx].shape,requires_grad=True)
        self.scale = torch.diag(torch.ones(self.features))#reset input scale
        self.out_scale = 1#reset output scale
        self.rss = 0#reset parameter heuristic
        self.mse = 0#reset mean squared error
        
    def mat_parse(self,inpt):#convenient method for converting pytorch tensors to text for csv export
        ret_str = ''
        for idx in inpt:
            for jdx in idx:
                ret_str+=str(jdx.item())+','
            ret_str+='\n'
        ret_str+='\n'
        return ret_str
    
    def to_csv(self,filname,method = 'a'):#convenient method for saving parameters to csv (for later processing in excel)
        fil = open(filname,method)
        fil.write('Input Features:,'+str(self.features)+'\n')
        fil.write('Network Structure:,'+str(self.structure)+'\n')
        fil.write('Bias:,'+str(self.bias)+'\n')
        fil.write('Activation Function:,'+str(self.activation)+'\n')
        if self.mse != 0:
            fil.write('MSE:,'+str(self.mse)+'\n\n')
        fil.write('Input Scale Matrix:\n')
        fil.write('Multiply the below matrix to any inputs applied to the network for inference\n')
        fil.write(self.mat_parse(self.scale))
        for idx in self.weights:
            fil.write('Weight Matrix for Calculating Layer Activations:\n')
            fil.write(self.mat_parse(idx))
        fil.write('Factor to Scale Output:\n')
        fil.write(str(1/self.out_scale)+'\n')
        fil.close()

    def export_data(self,inp,filname='data.csv',method='w'):#method for saving output data to file
        fil = open(filname,method)
        self.forward(inp)
        for idx in self.out:
            for jdx in idx:
                fil.write(str(jdx.item())+'\n')
        fil.close()
choice = 0
while (choice != '1' and choice != '2'):
    print('Would you like to load pretrained models or retrain models now (takes about 5 minutes)?')
    choice = input('1. Load Models\n2. Train Now\nType 1 or 2->')
    
if choice == '1':
    fil = open('pretrained_models.dat','rb')
    [net3,net15,net75,net75_reg] = pickle.load(fil)
    fil.close()
    print('Models Loaded from pretrained_models.dat')
else:
    #3 parameter mode
    inp = torch.cat((data[:-1]**2,data[:-1]),1)#initialize input data into a single pytorch x(n-1),x(n-1)**2
    y = data[1:]#arrange output data x(n) 
    net3 = network(2,[1])#initialize network 2 input features, 1 layer with 1 neuron with biases, and linear activation function
    
    net3.normalize(inp)#calculate scale factor for normalizing input
    
    net3.train(inp,y)#train once to get an initial mse for setting up loop conditional
    track = net3.mse#tracking variable for comparing mse change between interations
    
    mse = []
    lr = []
    grad_heur = []
    t1 = time.time()
    t2 = t1
    cnt = 0
    while net3.mse > 27 and cnt < 10:# train until either mse is below 28 or gradient is near zero
        net3.train(inp,y)# training iteration, one full sweep through all samples
        if track-net3.mse == 0:
            cnt+=1
        if net3.mse - track > 0:#reduce learning rate to avoid instabilities if error increases
            net3.eta/= 2
        elif net3.rss > 2:#increase learning rate if there is still a large gradient (rss >2)
            if (track - net3.mse)/net3.mse < .001:# if error change is too small then increase learning rate
                net3.eta *= 1.25
        track = net3.mse#update error tracking variable
        mse.append(net3.mse)#save historical mse for reporting later
        lr.append(net3.eta)#save historical learning rate for reporting later
        grad_heur.append(net3.rss)#save gradient heuristic for reporting later
        if time.time() - t2 > 5:
            print('\n')
            print('3-Parameter Network')
            print("MSE: "+str(net3.mse))#report results for training monitoring
            print('Learning Rate:'+str(net3.eta))
            print("Gradient Heuristic: "+str(net3.rss))
            print('')
            t2 = time.time()
            t1 = t2
        elif time.time() - t1 > 0.5:
            print('-',end='')
            t1 = time.time()
    print('\nFinal Result:')
    print('3-Parameter Network')
    print("MSE: "+str(net3.mse))#report results for training monitoring
    print('Learning Rate:'+str(net3.eta))
    print("Gradient Heuristic: "+str(net3.rss))
    print('')
    
    net3.to_csv('output3_bias_linear.parameters.csv')
    net3.export_data(inp,'3param_data.csv')
    
    fil = open('net3_hyperparameters.csv','w')
    fil.write('Iteration,MSE,Learning Rate,Gradient Heuristic\n')
    for i in range(len(mse)):
        fil.write(str(i+1)+','+str(mse[i])+','+str(lr[i])+','+str(grad_heur[i])+'\n')
    fil.close()
    
    #15 parameter model 
    inp = torch.cat((data[:-2],data[1:-1]),1)#construct input tensor, x(n-1) x(n-2)
    y = data[2:]
    net15 = network(2,[2,2,1],True,torch.sigmoid)#initial network,2 input features, 2 hidden layers with 2 neurons each, and biases
    net15.normalize(inp)#calculate scale for normalizing inputs
    
    net15.train(inp,y)
    track = net15.mse
    
    mse = []
    lr = []
    grad_heur = []
    
    net15.train(inp,y)
    net15.eta = min(net15.eta,.9/net15.rss)#initialize learning rate based on size of gradient
    cnt = 0
    t1 = time.time()
    t2 = t1
    while net15.mse > 21 and cnt < 10:#train until either mse goes below 21 or after 10 training cycles there's no change in error
        track = net15.mse
        net15.train(inp,y)
        if net15.mse - track > 0:#update learning rate to avoid training instabilities and keep a decent training speed
            net15.eta/= 10
        elif net15.rss > 2:
            if (track - net15.mse)/net15.mse < .0001:
                net15.eta *= 1.25
        if track - net15.mse == 0:
            cnt+=1
        mse.append(net15.mse)
        lr.append(net15.eta)
        grad_heur.append(net3.rss)
        if time.time() - t2 > 5:
            print('\n')
            print('15-Parameter Network')
            print("MSE: "+str(net15.mse))
            print('Learning Rate:'+str(net15.eta))
            print("Gradient Heuristic: " + str(net15.rss))
            print('')
            t2 = time.time()
            t1 = t2
        elif time.time() - t1 > 0.5:
            print('-',end='')
            t1 = time.time()
    print('\nFinal Result:')
    print('15-Parameter Network')
    print("MSE: "+str(net15.mse))
    print('Learning Rate:'+str(net15.eta))
    print("Gradient Heuristic: " + str(net15.rss))
    print('')
    
    net15.to_csv('output15_bias_sigmoid_parameters.csv','w')
    net15.export_data(inp,'15param_data.csv')
    
    fil = open('net15_hyperparameters.csv','w')
    fil.write('Iteration,MSE,Learning Rate,Gradient Heuristic\n')
    for i in range(len(mse)):
        fil.write(str(i+1)+','+str(mse[i])+','+str(lr[i])+','+str(grad_heur[i])+'\n')
    fil.close()
    
    
    #75 parameter mode
    inp = torch.cat((data[:-2],data[1:-1]**2,data[1:-1]),1)#initialize inputs. features: x(n-2), x(n-1)**2, x(n-1)
    y = data[2:]
    net75 = network(3,[5,4,5,1],True,torch.sigmoid)#initialize network 3 features, 3 hidden layers, 5 neurons, 4 neruons, 5 neurons, 1 output layer- sigmoid activation
    net75.normalize(inp)
    
    net75.train(inp,y)
    track = net75.mse
    
    mse = []
    lr = []
    grad_heur = []
    
    net75.eta = min(net75.eta,.9/net75.rss)
    cnt = 0
    t1 = time.time()
    t2 = t1
    while net75.mse > 19 and cnt < 10:
        track = net75.mse
        net75.train(inp,y)
        if net75.mse - track > 0:
            net75.eta/= 10
        elif net75.rss > 2:
            if (track - net75.mse)/net75.mse < .0001:
                net75.eta *= 1.25
        if track - net75.mse == 0:
            cnt+=1
        mse.append(net75.mse)
        lr.append(net75.eta)
        grad_heur.append(net75.rss)
        if time.time() - t2 > 5:
            print('\n')
            print('75 Parameter Network: No regularization')
            print("MSE: "+str(net75.mse))
            print('Learning Rate:'+str(net75.eta))
            print("Gradient Heuristic: " + str(net75.rss))
            print('')
            t2 = time.time()
            t1 = t2
        elif time.time() - t1 > 0.5:
            print('-',end='')
            t1 = time.time()
    
    print('\nFinal Result:')
    print('75 Parameter Network: No regularization')
    print("MSE: "+str(net75.mse))
    print('Learning Rate:'+str(net75.eta))
    print("Gradient Heuristic: " + str(net75.rss))
    print('')
    
    net75.to_csv('otpt75_bias_sigmoid_parameters.csv','w')
    net75.export_data(inp,'75param_data.csv')
    
    
    fil = open('net75_hyperparameters.csv','w')
    fil.write('Iteration,MSE,Learning Rate,Gradient Heuristic\n')
    for i in range(len(mse)):
        fil.write(str(i+1)+','+str(mse[i])+','+str(lr[i])+','+str(grad_heur[i])+'\n')
    fil.close()
    
    #75 parameter model with regularization
    
    inp = torch.cat((data[:-2],data[1:-1]**2,data[1:-1]),1)
    y = data[2:]
    net75_reg = network(3,[5,4,5,1],True,torch.sigmoid)
    net75_reg.normalize(inp)
    
    net75_reg.train(inp,y,True)#train with a regularization term
    track = net75_reg.mse
    
    mse = []
    lr = []
    grad_heur = []
    
    net75_reg.eta = min(net75_reg.eta,.9/net75_reg.rss)
    
    ##############################################################
    ####lamda defaults to .001 when network is first initialized
    ####uncomment to change lambda parameter
    #net75_reg.lam = .0005
    ###############################################################
    cnt = 0
    t1 = time.time()
    t2 = t1
    while net75_reg.mse > 19 and cnt < 10:
        track = net75_reg.mse
        net75_reg.train(inp,y,True)
        if net75_reg.mse - track > 0:
            net75_reg.eta/= 10
        elif net75_reg.rss > 2:
            if (track - net75_reg.mse)/net75_reg.mse < .0001:
                net75_reg.eta *= 1.25
        if track - net75_reg.mse == 0:
            cnt+=1
        mse.append(net75_reg.mse)
        lr.append(net75_reg.eta)
        grad_heur.append(net75_reg.rss)
        if time.time() - t2 > 5:
            print('\n')
            print('75 Parameter Network with Regularization- Lambda = '+str(net75_reg.lam))
            print("MSE: "+str(net75_reg.mse))
            print('Learning Rate:'+str(net75_reg.eta))
            print("Gradient Heuristic: "+str(net75_reg.rss))
            print('')
            t2 = time.time()
            t1 = t2
        elif time.time() - t1 > 0.5:
            print('-',end='')
            t1 = time.time()
    
    print('\nFinal Result:')
    print('75 Parameter Network with Regularization- Lambda = '+str(net75_reg.lam))
    print("MSE: "+str(net75_reg.mse))
    print('Learning Rate:'+str(net75_reg.eta))
    print("Gradient Heuristic: "+str(net75_reg.rss))
    
    net75_reg.to_csv('otpt75_bias_sigmoid_regularization_parameters.csv','w')
    net75_reg.export_data(inp,'75param_reg_data.csv')
    
    fil = open('net75reg_hyperparameters.csv','w')
    fil.write('Iteration,MSE,Learning Rate,Gradient Heuristic\n')
    for i in range(len(mse)):
        fil.write(str(i+1)+','+str(mse[i])+','+str(lr[i])+','+str(grad_heur[i])+'\n')
    fil.close()
    
    ##############
    ###Summary
    print('\n\n-----------------------------------------------------------')
    print('Summary of Training:')
    print('---------------------')
    print('3 Parameter Network')
    print('MSE:'+str(net3.mse))
    print('Gradient Heuristic (RSS):'+str(net3.rss))
    print('Final Learning Rate:'+str(net3.eta))
    print('-')
    print('15 Parameter Network')
    print('MSE:'+str(net15.mse))
    print('Gradient Heuristic (RSS):'+str(net15.rss))
    print('Final Learning Rate:'+str(net15.eta))
    print('-')
    print('75 Parameter Network No Regularization')
    print('MSE:'+str(net75.mse))
    print('Gradient Heuristic (RSS):'+str(net75.rss))
    print('Final Learning Rate:'+str(net75.eta))
    print('-')
    print('75 Parameter Network with Parameter Regularization')
    print('MSE:'+str(net75_reg.mse))
    print('Gradient Heuristic (RSS):'+str(net75_reg.rss))
    print('Final Learning Rate:'+str(net75_reg.eta))
    print('Lambda:'+str(net75_reg.lam))
    print('-')
    choice = input('\n\nDo you want to save the newly trained models?[y/n]: ')
    if choice == 'y':
        fname = input('Filename: ')+'_.dat'
        fil = open(fname,'wb')
        pickle.dump([net3,net15,net75,net75_reg],fil)
        fil.close()
        print('Models are saved under '+fname+' and may be loaded per the following pickle commands:')
        print('file = open(\''+fname+'\',\'rb\')')
        print('[net3,net15,net75,net75_reg] = pickle.load(\''+fname+'\')')
        print('file.close()')

print('\n\n-------------------------------------------------------')
print('MSE Calculation of trained Models')
print('Please save a comma-delimited CSV file of groundtruth values in the same working directoty as the python file.')
fname = input('CSV filename for ground truth calculation (Hit enter to default to \'ground_truth.csv\'):')

if fname == '':
    fname = 'ground_truth.csv'

fil= open(fname,'r')
x = fil.readline()
temp = []
while x!='':
    temp.append(x)
    x = fil.readline()
fil.close()

ground_truth = []
for idx in temp:
    temp2 = ''
    for j in idx:
        if j == ',':
            break
        temp2 += j
    ground_truth.append(float(temp2))

ground_truth_torch = torch.tensor(ground_truth).unsqueeze_(-1)
inp3 = torch.cat((ground_truth_torch[:-1].square(),ground_truth_torch[:-1]),1)
inp15 = torch.cat((ground_truth_torch[:-2],ground_truth_torch[1:-1]),1)
inp75 = torch.cat((ground_truth_torch[:-2],ground_truth_torch[1:-1].square(),ground_truth_torch[1:-1]),1)

net3.forward(inp3)
net15.forward(inp15)
net75.forward(inp75)
net75_reg.forward(inp75)

otpt3 = ground_truth_torch[1:]
otpt15 = ground_truth_torch[2:]
otpt75 = ground_truth_torch[2:]

mse3 = (otpt3 - net3.out).square().sum().item()/otpt3.shape[0]
mse15 = (otpt15 - net15.out).square().sum().item()/otpt15.shape[0]
mse75 = (otpt75 - net75.out).square().sum().item()/otpt75.shape[0]
mse75_reg = (otpt75 - net75_reg.out).square().sum().item()/otpt75.shape[0]

print('MSE for each network:')
print('3-parameter: '+str(mse3))
print('15parameter: '+str(mse15))
print('75-parameter: '+str(mse75))
print('75-parameter with regularization: '+str(mse75_reg))


################################################################################
################################################################################
################################################################################
###Old code used for testing out ideas
###kept here for documentation purposes but may be largely ignored
# params = torch.randn(3,requires_grad=True)

# eta = 0.0016248938271185617

# out = torch.matmul(test,params.unsqueeze(-1))
# error = (data[3:] - out[:-1])**2
# terr = error.sum()
# track = terr.item()

# while terr > 15153:
#     out = torch.matmul(test,params.unsqueeze(-1))
#     error = (data [3:]- out[:-1])**2
#     terr = error.sum()
#     print(terr.item())
#     derr = terr - track
#     if derr > 0:
#         if derr > terr/100:
#             eta/=10
#     elif (track - terr)/terr < .0001:
#         eta *= 1.25
#     track = terr.item()
#     terr.backward()
#     with torch.no_grad():
#         params -= eta*params.grad
#         params.grad.zero_()